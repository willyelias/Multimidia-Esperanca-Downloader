﻿@echo off
chcp 65001 >nul
title Instalador - Multimídia Esperança Downloader
echo ========================================================
echo   Preparando Multimídia Esperança Downloader...
echo ========================================================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File -ErrorAction SilentlyContinue; $targetDir = Join-Path $env:LOCALAPPDATA 'MultimidiaEsperancaDownloader'; New-Item -ItemType Directory -Force -Path $targetDir | Out-Null; $exeSource = Join-Path '%~dp0' 'Multimídia Esperança Downloader.exe'; $exeDest = Join-Path $targetDir 'Multimídia Esperança Downloader.exe'; Copy-Item $exeSource $exeDest -Force; Unblock-File -Path $exeDest -ErrorAction SilentlyContinue; $wsh = New-Object -ComObject WScript.Shell; $lnk = $wsh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Multimídia Esperança Downloader.lnk')); $lnk.TargetPath = $exeDest; $lnk.WorkingDirectory = $targetDir; $lnk.IconLocation = $exeDest; $lnk.Description = 'Multimídia Esperança Downloader'; $lnk.Save(); Start-Process $exeDest"
exit
